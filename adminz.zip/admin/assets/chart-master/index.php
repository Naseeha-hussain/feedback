<?php
header("location: http://www.noidatut.com/");

?>