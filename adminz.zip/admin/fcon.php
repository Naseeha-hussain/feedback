<?php
$confaculty=mysqli_connect('localhost','root','','aubit') or die(mysql_error());

 
?>