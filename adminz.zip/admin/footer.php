  <div class="text-center">
      <div class="credits">
        
          <p>University College Of Engineering,BIT campus</p>
        </div>
    </div>