<aside>
      <div id="sidebar" class="nav-collapse ">
        <!-- sidebar menu start-->
        <ul class="sidebar-menu">
          <li class="">
            <a class="" href="view-feedback-fc.php">
                          <i class="icon_house_alt"></i>
                          <span>Dashboard</span>
                      </a>
          </li>
          <li class="sub-menu">
         <a href="javascript:;" class="">
           <i class="icon_desktop"></i>
           <span>FeedBack</span>
           <span class="menu-arrow arrow_carrot-right"></span>
         </a>
         <ul class="sub">
           <li><a class="" href="view-feedback-fc.php">View FeedBack</a></li>
         </ul>
       </li>
		   <li>
            <a class="" href="faculty-info.php">
              <i class="icon_genius"></i>
              <span>Feedback Report</span>
            </a>
        </li>
        <li>
            <a class="" href="../index.php">
                          <i class="menu-arrow arrow_carrot-right"></i>
                          <span>Log Out</span>
                      </a>

          </li>
        </ul>
        <!-- sidebar menu end-->
      </div>
    </aside>