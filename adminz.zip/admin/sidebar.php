 <aside>
      <div id="sidebar" class="nav-collapse ">
        <!-- sidebar menu start-->
        <ul class="sidebar-menu">
          <li class="">
            <a class="" href="view-faculty.php">
                          <i class="icon_house_alt"></i>
                          <span>Dashboard</span>
                      </a>
          </li>
          <li class="sub-menu">
            <a href="javascript:;" class="">
                          <i class="icon_document_alt"></i>
                          <span>Faculty</span>
                          <span class="menu-arrow arrow_carrot-right"></span>
                      </a>
            <ul class="sub">
              <li><a class="" href="view-faculty.php">View Faculty</a></li>
              <li><a class="" href="add-faculty.php">Add Faculty</a></li>
            </ul>
          </li>
          <li class="sub-menu">
            <a href="javascript:;" class="">
                          <i class="icon_document_alt"></i>
                          <span>Student</span>
                          <span class="menu-arrow arrow_carrot-right"></span>
                      </a>
            <ul class="sub">
              <li><a class="" href="view-student.php">View Student</a></li>
              <li><a class="" href="add_student.php">Add Student</a></li>
            </ul>
          </li>
          <li class="sub-menu">
            <a href="javascript:;" class="">
                          <i class="icon_desktop"></i>
                          <span>Subject</span>
                          <span class="menu-arrow arrow_carrot-right"></span>
                      </a>
            <ul class="sub">
              <li><a class="" href="view-subject.php">View Subject</a></li>
              <li><a class="" href="add_subject.php">Add Subject</a></li>
           
            </ul>
            <li class="sub-menu">
            <a href="javascript:;" class="">
                          <i class="icon_document_alt"></i>
                          <span>Report</span>
                          <span class="menu-arrow arrow_carrot-right"></span>
                      </a>
            <ul class="sub">
              <li><a class="" href="view-Breport.php">Batch Wise</a></li>
              <li><a class="" href="view-Dreport.php">Dept Wise</a></li>
              <li><a class="" href="view-freport.php">Faculty Wise</a></li>
            </ul>
          </li>
          </li>
          <li>
            <a class="" href="view-feedback.php">
              <i class="icon_genius"></i>
              <span>View Feedback</span>
            </a>
          </li>
          <!-- <li>
            <a class="" href="contactus.php">
                          <i class="icon_piechart"></i>
                          <span>Contact Us</span>

                      </a>

          </li> -->

        <li>
            <a class="" href="logout.php">
                          <i class="menu-arrow arrow_carrot-right"></i>
                          <span>Log Out</span>

                      </a>

          </li>

       

        </ul>
        <!-- sidebar menu end-->
      </div>
    </aside>